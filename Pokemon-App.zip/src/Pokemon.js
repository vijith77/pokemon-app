import React, { useEffect, useState } from "react";
import { Typography, Link, CircularProgress, Button, Card, CardContent, Grid, AppBar, Toolbar } from "@material-ui/core";
import axios from "axios";


const toFirstCharUppercase = name =>
    name.charAt(0).toUpperCase() + name.slice(1);

const Pokemon = (props) => {
    const { match, history } = props;
    const { params } = match;
    const { pokemonId } = params;
    const [pokemon, setPokemon] = useState(undefined);

    useEffect(() => {
        axios
            .get(`https://pokeapi.co/api/v2/pokemon/${pokemonId}/`)
            .then(function (response) {
                const { data } = response;
                setPokemon(data);
            })
            .catch(function (error) {
                setPokemon(false);
            });
    }, [pokemonId]);



    const generatePokemonJSX = (pokemon) => {
        const { name, id, species, height, weight, types, sprites } = pokemon;
        const imageUrl = `https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/${id}.png`;
        const { front_default } = sprites;
        return (


            <>
                <Grid
                    container
                    spacing={0}
                    alignItems="center"
                    justifyContent="center"
                    style={{ minHeight: "100vh" }}
                >
                    <Grid item xs={12} sm={5}>
                        <Card>
                            <CardContent className="pPageContentMain">
                                <CardContent className="pPageContentinnerFirst">
                                    <Typography variant="h3">
                                        {`${id}.`} {toFirstCharUppercase(name)}
                                        <img src={front_default} />
                                    </Typography>
                                    <img style={{ width: "250px", height: "250px" }} src={imageUrl} />

                                    <Grid item xs={12} className="pPageContentInfoMain">
                                        <Typography variant="h4" className="pTitle">Pokemon Info</Typography>
                                        <Card>
                                            <CardContent className="infoDetails">
                                                <Typography>
                                                    {"Species: "}
                                                    <Link href={species.url}>{species.name} </Link>
                                                </Typography>
                                                <Typography>Height: {height} </Typography>
                                                <Typography>Weight: {weight} </Typography>
                                                <Typography variant="h6"> Types:</Typography>
                                                {types.map((typeInfo) => {
                                                    const { type } = typeInfo;
                                                    const { name } = type;
                                                    return <Typography key={name}> {`${name}`}</Typography>;
                                                })}
                                            </CardContent>
                                        </Card>

                                    </Grid>
                                    {pokemon !== undefined && (
                                        <Button variant="contained" onClick={() => history.push("/")} color="secondary">
                                            back to dashboard
                                        </Button>
                                    )}
                                </CardContent>
                            </CardContent>
                        </Card>
                    </Grid>
                </Grid>
            </>


        );
    };

    return (
        <>
            <AppBar position="static">
                <Toolbar>
                    <Grid item xs={12} className="pmainTitle"><h2>Pokemon</h2></Grid>
                </Toolbar>
            </AppBar>
            {pokemon === undefined && <CircularProgress />}
            {pokemon !== undefined && pokemon && generatePokemonJSX(pokemon)}
            {pokemon === false && <Typography> Pokemon not found</Typography>}


        </>
    );
};

export default Pokemon;